# Riiid-Answer-Correctness-Prediction-Kaggle 2ITE ENSAJ
Riiid Answer Correctness Prediction with LGBM Algorithm
Réalisé par ARJANE KHADIJA & CHARHABIL SANAA
Sous Ecadrement Pr. Rahhal ERRATTAHI
